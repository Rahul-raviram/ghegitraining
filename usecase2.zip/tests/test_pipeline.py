"""Unit tests for pipeline functions. LLM calls are mocked via a fake client."""
from __future__ import annotations

import pytest
from services.pipeline import run_full_pipeline


class FakeLLM:
    def __init__(self, responses=None):
        self.responses = responses or []
        self.calls = 0

    def call(self, messages, **kwargs):
        self.calls += 1
        if self.calls == 1:
            # analysis agent -> return a simple JSON string
            return '{"components": [{"name": "Example", "description": "An example", "responsibilities": ["do work"], "inputs": [], "outputs": [], "dependencies": []}], "processing_logic": "Simple flow."}'
        else:
            # refine agent -> return markdown
            return "# Final Document\n\nThis is the refined document."


# behavior that uses the repository `./src` folder (see `test_pipeline_with_repo_src`).

def test_pipeline_with_repo_src():
    """Integration-style test that runs against the repository ./src folder.
    Skips if the folder is not present (useful for CI or fresh clones).
    """
    from pathlib import Path

    repo_root = Path(__file__).resolve().parents[1]
    src = repo_root / "src"
    if not src.exists():
        pytest.skip("No ./src folder present for integration test")

    llm = FakeLLM()
    analysis, final, usage = run_full_pipeline(llm, str(src))

    assert isinstance(analysis, dict)
    # Analysis may be a structured dict or a raw fallback
    assert 'components' in analysis or 'raw' in analysis
    assert isinstance(final, str) and len(final) > 0
    # When using the fake LLM no usage info is available; ensure keys exist
    assert isinstance(usage, dict)
    assert 'analysis' in usage and 'refinement' in usage
