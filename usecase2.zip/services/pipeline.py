"""Pipeline helpers to collect legacy source files and orchestrate agent calls.

Zip archive inputs are no longer supported; place legacy sources in a directory (e.g. `./src`)."""
from __future__ import annotations

import os
from typing import List, Tuple


def collect_source_files(path: str, extensions: List[str] = None) -> List[Tuple[str, str]]:
    """Recursively collect files from `path` (expects a directory path). 

    Returns: list of (relative_path, content)
    """
    exts = extensions or [".java", ".cob", ".cbl", ".vb", ".txt", ".py"]
    result: List[Tuple[str, str]] = []

    for root, _dirs, files in os.walk(path):
        for fname in files:
            if any(fname.lower().endswith(e) for e in exts):
                full = os.path.join(root, fname)
                rel = os.path.relpath(full, path)
                try:
                    with open(full, 'r', encoding='utf-8', errors='replace') as fh:
                        content = fh.read()
                except Exception:
                    content = ''
                result.append((rel, content))

    return result


def run_full_pipeline(llm, source_path: str) -> Tuple[dict, str, dict]:
    """Collect files, run analysis agent, then refinement agent.

    Returns: (analysis_dict, final_markdown, usage_summary)
    where usage_summary is a dict like {"analysis": <usage>, "refinement": <usage>} — usage may be None if not available.
    """
    from agents.analyze_agent import run_analysis
    from agents.refine_agent import refine_document

    files = collect_source_files(source_path)

    analysis, analysis_usage = run_analysis(llm, files)
    final, refine_usage = refine_document(llm, analysis)

    usage_summary = {"analysis": analysis_usage, "refinement": refine_usage}

    return analysis, final, usage_summary
