"""Lightweight LLM client wrapper that uses AzureOpenAI (via openai package) and exposes a simple `call` method.
This is dependency-injectable so tests can mock it.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from openai import AzureOpenAI
from . import __name__ as _pkg


class LLMClient:
    def __init__(self, client: AzureOpenAI, deployment: Optional[str] = None, default_args: Optional[Dict[str, Any]] = None):
        self.client = client
        self.deployment = deployment
        self.default_args = default_args or {}

    def _extract_text_and_usage(self, resp: Any) -> Dict[str, Any]:
        """Normalize SDK response into a dictionary with text and usage details."""
        text = None
        usage = None

        # Try common SDK patterns
        try:
            # pydantic-like attribute access
            text = resp.choices[0].message.content
        except Exception:
            try:
                # dict-like access
                text = resp.get("choices", [])[0].get("message", {}).get("content")
            except Exception:
                text = None

        # usage info may be available at resp.usage or resp.get('usage')
        try:
            usage = getattr(resp, "usage", None) or (resp.get("usage") if isinstance(resp, dict) else None)
        except Exception:
            usage = None

        # Convert usage to dict if it has attributes
        if usage is not None and not isinstance(usage, dict):
            try:
                usage = usage.__dict__
            except Exception:
                try:
                    usage = dict(usage)
                except Exception:
                    usage = {"raw": str(usage)}

        return {"text": text, "usage": usage, "raw": resp}

    def call(self, messages: List[Dict[str, str]], temperature: float = 0.0, max_tokens: Optional[int] = None) -> Dict[str, Any]:
        if isinstance(messages, list):
            # Ensure messages are in the expected format
            msgs = messages
        else:
            # allow string shortcut
            msgs = [{"role": "user", "content": str(messages)}]

        if not self.deployment:
            raise RuntimeError("No Azure deployment configured for LLMClient")

        kwargs = {**self.default_args}
        kwargs["messages"] = msgs
        kwargs["model"] = self.deployment
        kwargs["temperature"] = temperature
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        resp = self.client.chat.completions.create(**kwargs)

        return self._extract_text_and_usage(resp)
