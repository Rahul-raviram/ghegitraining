"""Demo script that performs a single test call to Azure OpenAI using environment config from `config.py`.
This avoids hard-coded endpoints and deployment URLs in the repo.
"""
from __future__ import annotations

from config import get_azure_config
from openai import AzureOpenAI


def main():
    cfg = get_azure_config()

    if not cfg.azure_endpoint:
        raise RuntimeError("AZURE endpoint not set. Set AZURE_FULL_ENDPOINT or AZURE_ENDPOINT in .env")
    if not cfg.deployment:
        raise RuntimeError("AZURE_DEPLOYMENT is not set in .env; specify the deployment name to call the model")

    client = AzureOpenAI(api_version=cfg.api_version, azure_endpoint=cfg.azure_endpoint, api_key=cfg.azure_key)

    resp = client.chat.completions.create(
        model=cfg.deployment,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Say hello, and confirm deployment name."},
        ],
        max_tokens=200,
        temperature=0.0,
    )

    try:
        print(resp.choices[0].message.content)
    except Exception:
        print(resp)


if __name__ == "__main__":
    main()