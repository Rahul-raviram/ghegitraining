"""Streamlit UI that analyzes legacy code from the repository `./src` folder and shows the generated documentation.

This simplified UI reads from a local `./src` path.

Note: prefer running via `streamlit run ui/streamlit_app.py`. If you run the module directly with
`python ui/streamlit_app.py`, we add the repository root to `sys.path` to allow local imports to work.
"""
from __future__ import annotations

import sys
from pathlib import Path
import streamlit as st
import os

# Ensure repo root is on sys.path so local imports like `config` resolve when the script is run directly
repo_root = Path(__file__).resolve().parents[1]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from config import get_azure_config
from openai import AzureOpenAI
from services.llm import LLMClient
from services.pipeline import run_full_pipeline


st.set_page_config(page_title="Legacy Code Analyzer", layout="wide")
st.title("Legacy Code Analyzer & Migration Documenter")


def build_llm_client():
    cfg = get_azure_config()
    if not cfg.azure_endpoint:
        st.error("AZURE endpoint not set (AZURE_FULL_ENDPOINT or AZURE_ENDPOINT). Check your .env file.")
        return None

    client = AzureOpenAI(api_version=cfg.api_version, azure_endpoint=cfg.azure_endpoint, api_key=cfg.azure_key)
    deployment = cfg.deployment
    if not deployment:
        st.warning("No deployment specified in env; ensure one is set in AZURE_DEPLOYMENT to call the LLM.")

    return LLMClient(client=client, deployment=deployment)


st.sidebar.header("Input")
st.sidebar.info("This app analyzes legacy source located in the repository `./src` folder. Ensure files are present before running.")

# Surface agent responsibilities and token budgets
from agents.analyze_agent import ANALYZE_MAX_TOKENS
from agents.refine_agent import REFINE_MAX_TOKENS

st.sidebar.header("Agents")
st.sidebar.markdown(
    f"- **Analysis Agent** — extracts components, responsibilities, inputs/outputs, dependencies and high-level processing logic. Token budget: **{ANALYZE_MAX_TOKENS}** tokens.\n"
    f"- **Refinement Agent** — refines, autocorrects, and converts analysis into a final Markdown migration document. Token budget: **{REFINE_MAX_TOKENS}** tokens."
)

# Resolve the `src` path relative to the repository root so the app works regardless of current working directory
path_input = str(repo_root / "src")

if st.sidebar.button("Run Analysis on ./src"):
    llm = build_llm_client()
    if llm is None:
        st.stop()

    # Ensure the src folder exists (we resolve against repo root)
    if not os.path.isdir(path_input):
        st.error(f"Source folder not found: {path_input}. Please add your legacy code to the repository `./src` folder.")
        st.stop()

    st.info(f"Using source folder: {path_input}")

    with st.spinner("Running analysis (this may take a while)..."):
        try:
            result = run_full_pipeline(llm, path_input)
            # Support both old (analysis, final) and new (analysis, final, usage) signatures
            if isinstance(result, tuple) and len(result) == 3:
                analysis, final_md, usage = result
            elif isinstance(result, tuple) and len(result) == 2:
                analysis, final_md = result
                usage    = {"analysis": None, "refinement": None}
            else:
                raise RuntimeError("Unexpected pipeline return signature")
        except Exception as e:
            st.error(f"Pipeline failed: {e}")
            raise

    st.success("Analysis complete — refined document generated")

    st.subheader("Final Document")
    st.markdown(final_md)

    st.subheader("Raw Analysis JSON")
    st.json(analysis)

    st.subheader("Token usage")
    # display token counts if available
    if usage.get("analysis") and isinstance(usage.get("analysis"), dict):
        an_tokens = usage["analysis"].get("total_tokens") or usage["analysis"].get("totalTokens") or usage["analysis"].get("total")
    else:
        an_tokens = None

    if usage.get("refinement") and isinstance(usage.get("refinement"), dict):
        rf_tokens = usage["refinement"].get("total_tokens") or usage["refinement"].get("totalTokens") or usage["refinement"].get("total")
    else:
        rf_tokens = None

    st.write(f"Analysis agent tokens used: **{an_tokens if an_tokens is not None else 'N/A'}**")
    st.write(f"Refinement agent tokens used: **{rf_tokens if rf_tokens is not None else 'N/A'}**")

    st.download_button("Download final document", data=final_md.encode('utf-8'), file_name="legacy_analysis.md", mime="text/markdown")
