"""Centralized configuration for Azure/OpenAI settings.
Reads from environment variables (supports .env) and validates required settings.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class AzureConfig:
    azure_endpoint: str
    azure_key: str
    deployment: str
    api_version: str = "2025-01-01-preview"


def get_azure_config() -> AzureConfig:
    endpoint = os.getenv("AZURE_FULL_ENDPOINT") or os.getenv("AZURE_ENDPOINT")
    key = os.getenv("AZURE_OPENAI_KEY_GPT4o") or os.getenv("AZURE_OPENAI_KEY")
    deployment = os.getenv("AZURE_DEPLOYMENT") or os.getenv("AZURE_DEPLOYMENT_NAME")
    api_version = os.getenv("AZURE_API_VERSION") or "2025-01-01-preview"

    if not key:
        raise RuntimeError("Missing Azure API key environment variable: AZURE_OPENAI_KEY_GPT4o")

    if not endpoint:
        # allow endpoint without full deployments path; callers should handle discovery
        endpoint = os.getenv("AZURE_BASE_ENDPOINT") or ""

    if not deployment:
        # Not always required (some adapters may list deployments), but warn
        deployment = ""

    return AzureConfig(azure_endpoint=endpoint, azure_key=key, deployment=deployment, api_version=api_version)
