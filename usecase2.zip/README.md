# Legacy Code Analyzer

This project contains a pipeline to analyze legacy source code (Java, COBOL, VB, etc.) using an Azure OpenAI model and produce a component-level migration document.

Quickstart

1. Create a `.env` file in repo root with at least:

   AZURE_FULL_ENDPOINT or AZURE_ENDPOINT
   AZURE_OPENAI_KEY_GPT4o
   AZURE_DEPLOYMENT

   Place legacy source code to analyze in the repo `./src/` folder (the app will auto-detect it).

Agents and token budgets

- Analysis Agent — extracts components, responsibilities, inputs/outputs, dependencies and high-level processing logic from source files. Token budget: **2000** tokens.
- Refinement Agent — refines, autocorrects, and converts the analysis into a final Markdown migration document. Token budget: **1500** tokens.

The Streamlit UI shows each agent's responsibilities and their token budgets in the sidebar.

2. Install dependencies:

   pip install -r requirements.txt

3. Run Streamlit UI:

   streamlit run ui/streamlit_app.py

4. Run tests:

   pytest
