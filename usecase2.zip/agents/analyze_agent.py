"""Agent that ingests source files and asks the LLM to produce a component-level analysis.
The agent emits a JSON-like summary that describes components, responsibilities, inputs/outputs, and processing logic.
"""
from __future__ import annotations

from typing import Dict, List, Tuple
import json


# Token budget for the analysis agent (controls max tokens requested from the model)
ANALYZE_MAX_TOKENS = 2000

PROMPT_TEMPLATE = (
    "You are an expert software engineer. Given the following source files from a legacy codebase (language may be Java, COBOL, VB or others),"
    " analyze them and produce a JSON document with the following structure:\n"
    "{\n"
    "  \"components\": [\n"
    "    {\n"
    "      \"name\": \"component name or file name\",\n"
    "      \"description\": \"Short description of what this component does\",\n"
    "      \"responsibilities\": [\"...\"],\n"
    "      \"inputs\": [\"...\"],\n"
    "      \"outputs\": [\"...\"],\n"
    "      \"dependencies\": [\"...\"]\n"
    "    }\n"
    "  ],\n"
    "  \"processing_logic\": \"High-level flow description and any important algorithms or rules\"\n"
    "}\n\n"
    "Base your analysis on the code excerpts provided. If you encounter unknowns or cannot determine an exact detail, mark it as a hypothesis and explain how one might verify it."
)


def run_analysis(llm, files: List[Tuple[str, str]]) -> Dict:
    """Run the analyze agent.

    Args:
        llm: An object with a .call(messages:list) -> str interface.
        files: List of tuples (relative_path, file_contents)

    Returns:
        A dictionary parsed from the LLM-produced JSON response.
    """
    # Build a compact preamble and attach files as context. Limit file sizes to avoid overly large prompts.
    max_per_file = 8_000  # chars
    file_blobs = []
    for path, content in files:
        snippet = content[:max_per_file]
        file_blobs.append(f"--- FILE: {path} ---\n{snippet}\n")

    content = "\n".join(file_blobs)
    prompt = PROMPT_TEMPLATE + "\nData:\n" + content + "\n\nProduce only the JSON document."

    messages = [
        {"role": "system", "content": "You are a precise code-analyst and documenter."},
        {"role": "user", "content": prompt},
    ]

    # Use the configured token budget
    resp = llm.call(messages=messages, temperature=0.0, max_tokens=ANALYZE_MAX_TOKENS)

    # Support both LLM clients that return a string (legacy/fake) or a dict with 'text' and 'usage'
    text = resp["text"] if isinstance(resp, dict) and resp.get("text") is not None else resp
    usage = resp["usage"] if isinstance(resp, dict) and resp.get("usage") is not None else None

    # Try to parse JSON from the response text; if parsing fails, return raw text under 'raw' key
    try:
        parsed = json.loads(text)
        return parsed, usage
    except Exception:
        return {"raw": text}, usage
