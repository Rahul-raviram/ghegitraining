"""Agent that refines and autocorrects the analysis into a final Markdown document suitable for the Streamlit UI."""
from __future__ import annotations

from typing import Any, Dict

# Token budget for the refinement agent — controls the max tokens requested during refinement
REFINE_MAX_TOKENS = 1500

PROMPT = (
    "You are a technical writer. Given the JSON analysis of a legacy codebase, refine and correct the document, expand ambiguous sections into concrete TODOs for migration, and output a final Markdown document."
)


def refine_document(llm, analysis: Dict[str, Any]) -> str:
    messages = [
        {"role": "system", "content": "You are a helpful technical writer who produces accurate, succinct documentation."},
        {"role": "user", "content": PROMPT + "\nData:\n" + str(analysis) + "\n\nProduce only the Markdown document."},
    ]

    resp = llm.call(messages=messages, temperature=0.0, max_tokens=REFINE_MAX_TOKENS)

    # Accept string or dict response
    if isinstance(resp, dict):
        text = resp.get("text")
        usage = resp.get("usage")
    else:
        text = resp
        usage = None

    return text, usage
